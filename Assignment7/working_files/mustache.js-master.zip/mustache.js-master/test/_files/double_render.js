({
  foo: true,
  bar: "{{win}}",
  win: "FAIL"
})
